This is assignment 2

Annie Pham
861145203 
Section 22