#ifndef __PARSE_H__
#define __PARSE_H__
#include <iostream>
#include <string>
#include <stack>
#include "Shell.h"
#include "Connector.h"

using namespace std;

class Parse {
    protected:
    	void createFork(vector<string> &,unsigned, unsigned);
        vector<Shell*> exec_cmds_vector;
    public:
        Parse() {}
        void par(string);
        
};

#endif 

