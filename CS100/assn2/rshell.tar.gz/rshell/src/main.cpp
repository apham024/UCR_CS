#include <iostream>
#include <vector>
#include <string>
#include <iterator>
#include <cstring> 
#include <sstream>
#include <algorithm>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h> 
#include "Shell.h"
#include "Forker.h"
#include "Parse.h"

using namespace std;

int main() {
	string line;	
	string arg = "";
	while(1) {
		Parse* p = new Parse();

		cout << "$ "; 
		//Gets a command
		getline(cin, line);  
		// parses and runs code
		p->par(line);
		delete p;
	}

	return 0;
}

