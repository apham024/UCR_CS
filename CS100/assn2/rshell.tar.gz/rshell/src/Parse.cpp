#include <iostream>
#include <algorithm>
#include <string>
#include <stack>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <vector>
#include "Parse.h"
#include "Forker.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/errno.h>
#include <sys/stat.h>
#include <cstdio>

using namespace std;

void Parse::createFork(vector<string> &cmds_vector, unsigned i, unsigned j) {
    vector<string> cmd;
    for (unsigned k = i; k < j; ++k) {
        if (cmds_vector.at(k) != "\"") {
            cmd.push_back(cmds_vector.at(k));
        }
    }
    exec_cmds_vector.push_back(new Forker(cmd));
}


void Parse::par(string in) {
    const string a = "&&";
    const string o = "||";
    const string s = ";";
    
    // parse command line and store in cmds_vector 
    char cmds[1024];
    char *ptr;
    // converts cmds from strings to chars
    //vector<string< p_vector;
    vector<string> cmds_vector;
    strcpy(cmds, in.c_str());
    // parse white space
    ptr = strtok(cmds, " "); 
    // store parsed commands into cmds_vector
    while (ptr != NULL) {
        cmds_vector.push_back(ptr);
        ptr = strtok(NULL, " ");
    }
    // push elements from cmds_vector to exec_cmds_vector until hitting a connector
    // then execute everything before connector and clear
    // check for connector and execute next command depending on connector and if the last command pass/failed
    
    
    stack<Connector*> cmd_stack; 
    
    // comment case
    for (unsigned j = 0; j < cmds_vector.size(); ++j) {
        if ((cmds_vector.at(j))[0] == '#') {
            cmds_vector.resize(j);
            break;
        }
    }

    
    unsigned i;
    for (i = 0; i < cmds_vector.size();++i) {
        // Transferring Commands
        string indexString = cmds_vector.at(i);
        
        
        //connectors & commands
        if (cmds_vector.at(i) == a) {
            //check to see if exist a conn
            //push new operator onto stack
            cmd_stack.push(new And());
        }
        else if (cmds_vector.at(i) == o) {
            //check to see if exist a conn
            //push new operator onto stack
            cmd_stack.push(new Or());
        }
        else if (cmds_vector.at(i) == s) {
            //check to see if exist a conn
            //push new operator onto stack
            cmd_stack.push(new SemiColon());
        }

        else {//is part of the bash cmds
            //iterate until find a conn
            unsigned j = 0;
            for (j = i; j < cmds_vector.size(); ++j) {
                //if conn found
                if (cmds_vector.at(j) == a || 
                    cmds_vector.at(j) == o ||
                    cmds_vector.at(j) == s) {
                        //store strings into new Fork
                        createFork(cmds_vector, i, j);
                        i = j - 1; //need to add the conn
                        break;
                }
            }
            //if no conn found, means end of cmd_vector
            if (j >=  cmds_vector.size()) {
                //create new Fork
                createFork(cmds_vector, i, j);
                break;
            }
        }
    }
    
    if (!exec_cmds_vector.empty() && exec_cmds_vector.at(0)->execute()) {
        exec_cmds_vector.clear();
    }
}

