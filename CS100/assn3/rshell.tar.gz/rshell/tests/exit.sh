#!/bin/sh
# exit test #
$ cd rshell
$ ./a.out

exit
